package com.beautysalon.lab2_salon.Comparator;

import com.beautysalon.lab2_salon.Booking;

import java.util.Comparator;

public class BookingComparator implements Comparator<Booking> {
    @Override
    public int compare(Booking b1, Booking b2) {
        return b1.getStartDate().compareTo(b2.getStartDate());
    }
}
