package com.beautysalon.lab2_salon.Service;

import com.beautysalon.lab2_salon.Booking;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class BookingService {
    private final List<Booking> bookings;

    // Конструктор для ініціалізації списку бронювань
    public BookingService(List<Booking> bookings) {
        this.bookings = new ArrayList<>(bookings);
    }

    // Метод для отримання оплачених бронювань
    public List<Booking> getPaidBookings() {
        return bookings.stream()
                .filter(Booking::isPaid)
                .collect(Collectors.toList());
    }

    // Метод для сортування бронювань за датою початку
    public List<Booking> sortBookingsByStartDate() {
        return bookings.stream()
                .sorted(Comparator.comparing(Booking::getStartDate))
                .collect(Collectors.toList());
    }

    // Метод для отримання унікальних клієнтів
    public List<Object> getUniqueClients() {
        return bookings.stream()
                .map(Booking::getClient)
                .distinct()
                .collect(Collectors.toList());
    }

    // Метод для отримання бронювань в певному діапазоні дат
    public List<Booking> getBookingsBetweenDates(LocalDate from, LocalDate to) {
        return bookings.stream()
                .filter(booking ->
                        (booking.getStartDate().isAfter(from) || booking.getStartDate().isEqual(from)) &&
                                (booking.getStartDate().isBefore(to) || booking.getStartDate().isEqual(to))
                )
                .collect(Collectors.toList());
    }
}
