package com.beautysalon.lab2_salon;


import java.util.Objects;

/**
 * Клас, що представляє процедуру в салоні краси.
 */
public class Procedure {
    private String name;
    private int durationMinutes;
    private double price;
    private String description;

    // Конструктор
    public Procedure(String name, int durationMinutes, double price, String description) {
        this.name = name;
        this.durationMinutes = durationMinutes;
        this.price = price;
        this.description = description;
    }

    // Перевизначення методу toString
    @Override
    public String toString() {
        return "Procedure{" +
                "name='" + name + '\'' +
                ", durationMinutes=" + durationMinutes +
                ", price=" + price +
                ", description='" + description + '\'' +
                '}';
    }

    // Перевизначення методу equals
    // Procedure.java
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Procedure procedure = (Procedure) o;
        return durationMinutes == procedure.durationMinutes &&
                Double.compare(procedure.price, price) == 0 &&
                Objects.equals(name, procedure.name) &&
                Objects.equals(description, procedure.description);
    }

    // Перевизначення методу hashCode
    @Override
    public int hashCode() {
        return Objects.hash(name, durationMinutes, price, description);
    }
}
