package com.beautysalon.lab2_salon;


import java.time.LocalDate;
import java.util.Objects;

/**
 * Клас, що представляє клієнта салону краси.
 */

public class Client {
    private final String firstName;
    private final String lastName;
    private final String documentId;
    private final LocalDate birthDate;

    // Конструктор
    public Client(String firstName, String lastName, String documentId, LocalDate birthDate) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.documentId = documentId;
        this.birthDate = birthDate;
    }

    // Перевизначення методу toString
    @Override
    public String toString() {
        return "Client{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", documentId='" + documentId + '\'' +
                ", birthDate=" + birthDate +
                '}';
    }

    // Перевизначення методу equals
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Client client = (Client) o;
        return Objects.equals(firstName, client.firstName) &&
                Objects.equals(lastName, client.lastName) &&
                Objects.equals(documentId, client.documentId) &&
                Objects.equals(birthDate, client.birthDate);
    }

    // Перевизначення методу hashCode
    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName, documentId, birthDate);
    }
}
