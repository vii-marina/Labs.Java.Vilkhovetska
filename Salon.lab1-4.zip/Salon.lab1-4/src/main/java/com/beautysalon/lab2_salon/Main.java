package com.beautysalon.lab2_salon;

import com.beautysalon.lab2_salon.Service.BookingService;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Створення об'єктів Booking
        Client client1 = new Client("John", "Doe", "1234-5678", LocalDate.of(1990, 5, 15));
        Procedure procedure1 = new Procedure("Haircut", 60, 20.0, "Basic haircut");

        Booking booking1 = new Booking.Builder()
                .setClient(client1)
                .setProcedure(procedure1)
                .setStartDate(LocalDate.of(2024, 11, 1))
                .setEndDate(LocalDate.of(2024, 11, 2))
                .setPaid(true)
                .build();

        Booking booking2 = new Booking.Builder()
                .setClient(client1)
                .setProcedure(procedure1)
                .setStartDate(LocalDate.of(2024, 11, 5))
                .setEndDate(LocalDate.of(2024, 11, 6))
                .setPaid(false)
                .build();

        // Створення списку бронювань
        List<Booking> bookings = Arrays.asList(booking1, booking2);

        // Використання BookingService
        BookingService bookingService = new BookingService(bookings);

        System.out.println("Оплачені бронювання: " + bookingService.getPaidBookings());
        System.out.println("Сортування бронювань за датою початку: " + bookingService.sortBookingsByStartDate());
        System.out.println("Унікальні клієнти: " + bookingService.getUniqueClients());

        // Використання нового методу для фільтрації бронювань за датами
        LocalDate fromDate = LocalDate.of(2024, 11, 1);
        LocalDate toDate = LocalDate.of(2024, 11, 6);
        System.out.println("Бронювання з " + fromDate + " по " + toDate + ": " +
                bookingService.getBookingsBetweenDates(fromDate, toDate));
    }
}
