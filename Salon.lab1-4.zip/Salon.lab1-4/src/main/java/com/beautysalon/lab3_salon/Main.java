package com.beautysalon.lab3_salon;

import com.beautysalon.lab3_salon.serialization.*;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        Client client = new Client("John", "Doe", "12345", LocalDate.of(1990, 5, 15));

        File jsonFile = new File("client.json");
        File xmlFile = new File("client.xml");
        File yamlFile = new File("client.yaml");

        try {
            // Серіалізація в JSON
            EntitySerializer<Client> jsonSerializer = new JsonEntitySerializer<>();
            // jsonSerializer.serialize(client, jsonFile);
            Client deserializedClientJson = jsonSerializer.deserialize(jsonFile, Client.class);
            System.out.println("JSON десеріалізовано: " + deserializedClientJson);

            // Серіалізація в XML
            EntitySerializer<Client> xmlSerializer = new XmlEntitySerializer<>();
            xmlSerializer.serialize(client, xmlFile);
            Client deserializedClientXml = xmlSerializer.deserialize(xmlFile, Client.class);
            System.out.println("XML десеріалізовано: " + deserializedClientXml);

            // Серіалізація в YAML
            EntitySerializer<Client> yamlSerializer = new YamlEntitySerializer<>();
            yamlSerializer.serialize(client, yamlFile);
            Client deserializedClientYaml = yamlSerializer.deserialize(yamlFile, Client.class);
            System.out.println("YAML десеріалізовано: " + deserializedClientYaml);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
