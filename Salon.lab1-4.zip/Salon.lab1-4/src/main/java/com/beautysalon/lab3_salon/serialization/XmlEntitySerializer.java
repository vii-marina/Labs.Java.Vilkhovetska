package com.beautysalon.lab3_salon.serialization;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.io.File;
import java.io.IOException;

public class XmlEntitySerializer<T> implements EntitySerializer<T> {
    private XmlMapper xmlMapper = new XmlMapper();

    // Конструктор
    public XmlEntitySerializer() {
        this.xmlMapper = new XmlMapper();
        // Реєструємо модуль для підтримки Java 8 дат
        this.xmlMapper.registerModule(new JavaTimeModule());
    }

    @Override
    public void serialize(T entity, File file) throws IOException {
        xmlMapper.writeValue(file, entity);
    }

    @Override
    public T deserialize(File file, Class<T> clazz) throws IOException {
        return xmlMapper.readValue(file, clazz);
    }
}
