package com.beautysalon.lab3_salon.serialization;

import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.io.File;
import java.io.IOException;

public class YamlEntitySerializer<T> implements EntitySerializer<T> {
    private YAMLMapper yamlMapper = new YAMLMapper();

    // Конструктор
    public YamlEntitySerializer() {
        this.yamlMapper = new YAMLMapper();
        // Реєструємо модуль для підтримки Java 8 дат
        this.yamlMapper.registerModule(new JavaTimeModule());
    }

    @Override
    public void serialize(T entity, File file) throws IOException {
        yamlMapper.writeValue(file, entity);
    }

    @Override
    public T deserialize(File file, Class<T> clazz) throws IOException {
        return yamlMapper.readValue(file, clazz);
    }
}
