package com.beautysalon.lab3_salon;

import java.util.Date;
import java.util.Objects;

public class Booking {
    private final Client client;
    private final Procedure procedure;
    private final Date startDate;
    private final Date endDate;
    private final boolean isPaid;

    private Booking(Builder builder) {
        this.client = builder.client;
        this.procedure = builder.procedure;
        this.startDate = builder.startDate;
        this.endDate = builder.endDate;
        this.isPaid = builder.isPaid;
    }

    public static class Builder {
        public Client client;
        public Procedure procedure;
        public Date startDate;
        public Date endDate;
        public boolean isPaid;
    }

    @Override
    public String toString() {
        return "Booking{" + "client=" + client + ", procedure=" + procedure +
                ", startDate=" + startDate + ", endDate=" + endDate + ", isPaid=" + isPaid + '}';
    }
}
