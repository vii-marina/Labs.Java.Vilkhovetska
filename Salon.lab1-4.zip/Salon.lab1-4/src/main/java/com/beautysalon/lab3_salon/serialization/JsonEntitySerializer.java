package com.beautysalon.lab3_salon.serialization;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.io.File;
import java.io.IOException;

public class JsonEntitySerializer<T> implements EntitySerializer<T> {
    private ObjectMapper objectMapper = new ObjectMapper();

    // Конструктор
    public JsonEntitySerializer() {
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
    }


    @Override
    public void serialize(T entity, File file) throws IOException {
        objectMapper.writeValue(file, entity);
    }

    @Override
    public T deserialize(File file, Class<T> clazz) throws IOException {
        return objectMapper.readValue(file, clazz);
    }
}
