package com.beautysalon.lab3_salon;

import java.util.Objects;

public class Procedure {
    private final String name;
    private final int durationMinutes;
    private final double price;
    private final String description;

    public Procedure(String name, int durationMinutes, double price, String description) {
        this.name = name;
        this.durationMinutes = durationMinutes;
        this.price = price;
        this.description = description;
    }

    @Override
    public String toString() {
        return "Procedure{" + "name='" + name + '\'' +
                ", durationMinutes=" + durationMinutes +
                ", price=" + price + ", description='" + description + '\'' + '}';
    }
}
