package com.beautysalon.lab1.salon;

import java.time.LocalDate;
import java.util.Objects;

/**
 * Клас, що представляє бронювання процедури для клієнта.
 */
public class Booking {
    private final Client client;
    private final Procedure procedure;
    private final LocalDate startDate;
    private final LocalDate endDate;
    private final boolean isPaid;

    // Приватний конструктор
    private Booking(Builder builder) {
        this.client = builder.client;
        this.procedure = builder.procedure;
        this.startDate = builder.startDate;
        this.endDate = builder.endDate;
        this.isPaid = builder.isPaid;
    }

    // Створення класу Builder для побудови об'єктів Booking
    public static class Builder {
        private Client client;
        private Procedure procedure;
        private LocalDate startDate;
        private LocalDate endDate;
        private boolean isPaid;

        public Builder setClient(Client client) {
            this.client = client;
            return this;
        }

        public Builder setProcedure(Procedure procedure) {
            this.procedure = procedure;
            return this;
        }

        public Builder setStartDate(LocalDate startDate) {
            this.startDate = startDate;
            return this;
        }

        public Builder setEndDate(LocalDate endDate) {
            this.endDate = endDate;
            return this;
        }

        public Builder setPaid(boolean isPaid) {
            this.isPaid = isPaid;
            return this;
        }

        public Booking build() {
            return new Booking(this);
        }
    }

    // Методи toString, equals, hashCode
    @Override
    public String toString() {
        return "Booking{" +
                "client=" + client +
                ", procedure=" + procedure +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", isPaid=" + isPaid +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Booking booking = (Booking) o;
        return isPaid == booking.isPaid &&
                client.equals(booking.client) &&
                procedure.equals(booking.procedure) &&
                startDate.equals(booking.startDate) &&
                endDate.equals(booking.endDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(client, procedure, startDate, endDate, isPaid);
    }
}
