package com.beautysalon.lab1.salon;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        // Створення клієнта з коректними даними
        try {
            Client client = new Client.Builder()
                    .setFirstName("Anna")
                    .setLastName("Smith")
                    .setDocumentId("1234-5678")
                    .setBirthDate(LocalDate.of(2000, 5, 15)) // Вік 24 роки
                    .build();
            System.out.println("Клієнт створений успішно: " + client);
        } catch (IllegalArgumentException e) {
            System.out.println("Помилка при створенні клієнта: " + e.getMessage());
        }

        // Спроба створити клієнта з некоректною датою народження
        try {
            Client client = new Client.Builder()
                    .setFirstName("Bob")
                    .setLastName("Brown")
                    .setDocumentId("1234-5678")
                    .setBirthDate(LocalDate.of(2010, 6, 1)) // Вік 14 років, занадто молодий
                    .build();
            System.out.println("Клієнт створений успішно: " + client);
        } catch (IllegalArgumentException e) {
            System.out.println("Помилка при створенні клієнта: " + e.getMessage());
        }
    }
}
