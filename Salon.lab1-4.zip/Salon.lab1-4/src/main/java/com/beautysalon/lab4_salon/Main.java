package com.beautysalon.lab4_salon;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        try {
            Client.Builder builder = new Client.Builder();
            builder.setFirstName("John");
            builder.setLastName("Doe");
            builder.setDocumentId("1234-5678");
            builder.setBirthDate(LocalDate.of(1990, 5, 15));
            Client client = builder
                    .build();

            Procedure procedure = new Procedure.Builder()
                    .setName("Haircut")
                    .setDurationMinutes(30)
                    .setPrice(150.0)
                    .setDescription("Basic haircut")
                    .build();

            Booking booking = new Booking.Builder()
                    .setClient(client)
                    .setProcedure(procedure)
                    .setStartDate(LocalDate.of(1990, 5, 15))
                    .setEndDate(LocalDate.of(2020, 12, 30))
                    .setPaid(true)
                    .build();

            System.out.println("Booking successful: " + booking);

        } catch (IllegalArgumentException e) {
            System.err.println("Error creating entity: " + e.getMessage());
        }
    }
}
