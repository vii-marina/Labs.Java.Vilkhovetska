package com.beautysalon.lab4_salon;

import java.util.Objects;

public class Procedure {
    private final String name;
    private final int durationMinutes;
    private final double price;
    private final String description;

    private Procedure(Builder builder) {
        this.name = builder.name;
        this.durationMinutes = builder.durationMinutes;
        this.price = builder.price;
        this.description = builder.description;
    }

    public static class Builder {
        private String name;
        private int durationMinutes;
        private double price;
        private String description;

        private static final double MIN_PRICE = 100.0;
        private static final int MAX_DURATION = 240;

        public Builder setName(String name) {
            if (name == null || name.isEmpty()) {
                throw new IllegalArgumentException("Invalid name: cannot be empty");
            }
            this.name = name;
            return this;
        }

        public Builder setDurationMinutes(int durationMinutes) {
            if (durationMinutes <= 0 || durationMinutes > MAX_DURATION) {
                throw new IllegalArgumentException("Invalid duration: must be between 1 and " + MAX_DURATION + " minutes");
            }
            this.durationMinutes = durationMinutes;
            return this;
        }

        public Builder setPrice(double price) {
            if (price < MIN_PRICE) {
                throw new IllegalArgumentException("Invalid price: must be at least " + MIN_PRICE);
            }
            this.price = price;
            return this;
        }

        public Builder setDescription(String description) {
            this.description = description;
            return this;
        }

        public Procedure build() {
            return new Procedure(this);
        }
    }

    @Override
    public String toString() {
        return "Procedure{" +
                "name='" + name + '\'' +
                ", durationMinutes=" + durationMinutes +
                ", price=" + price +
                ", description='" + description + '\'' +
                '}';
    }
}
