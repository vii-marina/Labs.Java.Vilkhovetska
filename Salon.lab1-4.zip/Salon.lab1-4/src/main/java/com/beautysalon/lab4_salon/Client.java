package com.beautysalon.lab4_salon;

import java.time.LocalDate;
import java.util.regex.Pattern;
import java.util.Calendar;

public class Client {
    private final String firstName;
    private final String lastName;
    private final String documentId;
    private final LocalDate birthDate;

    private Client(Builder builder) {
        this.firstName = builder.firstName;
        this.lastName = builder.lastName;
        this.documentId = builder.documentId;
        this.birthDate = builder.birthDate;
    }

    public static class Builder {
        private String firstName;
        private String lastName;
        private String documentId;
        private LocalDate birthDate;

        private static final int MIN_AGE = 18;
        private static final int MAX_AGE = 80;
        private static final int NAME_MAX_LENGTH = 10;
        private static final Pattern DOCUMENT_ID_PATTERN = Pattern.compile("\\d{4}-\\d{4}");

        public Builder setFirstName(String firstName) {
            if (firstName == null || firstName.length() > NAME_MAX_LENGTH) {
                throw new IllegalArgumentException("Invalid firstName: length should be between 1 and " + NAME_MAX_LENGTH);
            }
            this.firstName = firstName;
            return this;
        }

        public Builder setLastName(String lastName) {
            if (lastName == null || lastName.length() > NAME_MAX_LENGTH) {
                throw new IllegalArgumentException("Invalid lastName: length should be between 1 and " + NAME_MAX_LENGTH);
            }
            this.lastName = lastName;
            return this;
        }

        public Builder setDocumentId(String documentId) {
            if (documentId == null || !DOCUMENT_ID_PATTERN.matcher(documentId).matches()) {
                throw new IllegalArgumentException("Invalid documentId: must match pattern ####-####");
            }
            this.documentId = documentId;
            return this;
        }

        public Builder setBirthDate(LocalDate birthDate) {
            if (birthDate == null) {
                throw new IllegalArgumentException("Invalid birthDate: cannot be null");
            }

            int age = calculateAge(birthDate);
            if (age < MIN_AGE || age > MAX_AGE) {
                throw new IllegalArgumentException("Invalid birthDate: age should be between " + MIN_AGE + " and " + MAX_AGE);
            }
            this.birthDate = birthDate;
            return this;
        }

        private int calculateAge(LocalDate birthDate) {
            LocalDate today = LocalDate.now();
            int age = today.getYear() - birthDate.getYear();

            // Перевіряємо, чи день народження був у цьому році
            if (today.getDayOfYear() < birthDate.getDayOfYear()) {
                age--;
            }

            return age;
        }


        public Client build() {
            return new Client(this);
        }
    }

    @Override
    public String toString() {
        return "Client{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", documentId='" + documentId + '\'' +
                ", birthDate=" + birthDate +
                '}';
    }
}
