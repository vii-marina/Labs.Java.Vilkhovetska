package com.beautysalon.lab4_salon;

import java.time.LocalDate;
import java.util.Objects;

public class Booking {
    private final Client client;
    private final Procedure procedure;
    private final LocalDate startDate;
    private final LocalDate endDate;
    private final boolean isPaid;

    private Booking(Builder builder) {
        this.client = builder.client;
        this.procedure = builder.procedure;
        this.startDate = builder.startDate;
        this.endDate = builder.endDate;
        this.isPaid = builder.isPaid;
    }

    public static class Builder {
        private Client client;
        private Procedure procedure;
        private LocalDate startDate;
        private LocalDate endDate;
        private boolean isPaid;

        public Builder setClient(Client client) {
            if (client == null) {
                throw new IllegalArgumentException("Invalid client: cannot be null");
            }
            this.client = client;
            return this;
        }

        public Builder setProcedure(Procedure procedure) {
            if (procedure == null) {
                throw new IllegalArgumentException("Invalid procedure: cannot be null");
            }
            this.procedure = procedure;
            return this;
        }

        public Builder setStartDate(LocalDate startDate) {
            if (startDate == null) {
                throw new IllegalArgumentException("Invalid startDate: cannot be null");
            }
            this.startDate = startDate;
            return this;
        }

        public Builder setEndDate(LocalDate endDate) {
            if (endDate == null || endDate.isBefore(startDate)) {
                throw new IllegalArgumentException("Invalid endDate: must be after startDate");
            }
            this.endDate = endDate;
            return this;
        }

        public Builder setPaid(boolean isPaid) {
            this.isPaid = isPaid;
            return this;
        }

        public Booking build() {
            return new Booking(this);
        }
    }

    @Override
    public String toString() {
        return "Booking{" +
                "client=" + client +
                ", procedure=" + procedure +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", isPaid=" + isPaid +
                '}';
    }
}
