package com.beautysalon.lab4_salon;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;

public class ClientTest {

    @Test
    public void testClientCreationSuccess() {
        Client client = new Client.Builder()
                .setFirstName("John")
                .setLastName("Doe")
                .setDocumentId("1234-5678")
                .setBirthDate(LocalDate.of(1995, 3, 10))
                .build();
        assertNotNull(client);
        assertTrue(client.toString().contains("John"));
    }


    @Test
    public void testInvalidDocumentId() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Client.Builder()
                    .setFirstName("Jane")
                    .setLastName("Doe")
                    .setDocumentId("INVALID_ID")
                    .setBirthDate(LocalDate.of(1995, 3, 10))
                    .build();
        });
        assertTrue(exception.getMessage().contains("Invalid documentId"));
    }
}