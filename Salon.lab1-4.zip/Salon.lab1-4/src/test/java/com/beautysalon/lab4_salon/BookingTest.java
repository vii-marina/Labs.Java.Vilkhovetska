package com.beautysalon.lab4_salon;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;

public class BookingTest {

    @Test
    public void testBookingCreationSuccess() {
        Client client = new Client.Builder()
                .setFirstName("Alice")
                .setLastName("Smith")
                .setDocumentId("1111-2222")
                .setBirthDate(LocalDate.of(1995, 3, 10)) // Вік 28 років
                .build();

        Procedure procedure = new Procedure.Builder()
                .setName("Haircut")
                .setDurationMinutes(30)
                .setPrice(300)
                .setDescription("Stylish haircut")
                .build();

        Booking booking = new Booking.Builder()
                .setClient(client)
                .setProcedure(procedure)
                .setStartDate(LocalDate.now()) // Або конкретна дата
                .setEndDate(LocalDate.now().plusDays(1)) // Наприклад, на наступний день
                .setPaid(true)
                .build();

        assertNotNull(booking);
        assertTrue(booking.toString().contains("Haircut"));
    }

    @Test
    public void testBookingWithNullClient() {
        Procedure procedure = new Procedure.Builder()
                .setName("Haircut")
                .setDurationMinutes(45)
                .setPrice(450)
                .setDescription("Haircut description")
                .build();

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Booking.Builder()
                    .setClient(null)
                    .setProcedure(procedure)
                    .setStartDate(LocalDate.now())
                    .setEndDate(LocalDate.now().plusDays(1))
                    .setPaid(true)
                    .build();
        });
        assertTrue(exception.getMessage().contains("Invalid client"));
    }
}
