package com.beautysalon.lab4_salon;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProcedureTest {

    @Test
    public void testProcedureCreationSuccess() {
        Procedure procedure = new Procedure.Builder()
                .setName("Massage")
                .setDurationMinutes(60)
                .setPrice(500)
                .setDescription("Relaxing massage")
                .build();
        assertNotNull(procedure);
        assertTrue(procedure.toString().contains("Massage"));
    }

    @Test
    public void testInvalidPrice() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Procedure.Builder()
                    .setName("Facial")
                    .setDurationMinutes(45)
                    .setPrice(50) // Недостатня ціна
                    .setDescription("Basic facial")
                    .build();
        });
        assertTrue(exception.getMessage().contains("Invalid price"));
    }
}
